Neighborhood Map Project

#steps to run:
- download the project and unZIP
-open index.html in your browser
-the map will apper !!!